This example demonstrates usage of EclipseLink's JPA support with access to a NoSQL
database, MongoDB.

The example assume the Mongo database is running locally on the default port, to use another database edit the persisence.xml
