EclipseLink MOXy Dynamic JSON Example
-------------------------------------

This example will demonstrate how to use EclipseLink Dynamic MOXy to unmarshal an XML document, and marshal it to a JSON document, using mappings defined in an MOXy bindings file.