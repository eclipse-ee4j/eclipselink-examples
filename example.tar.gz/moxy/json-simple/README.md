EclipseLink MOXy Simple JSON Example
------------------------------------

This example will demonstrate how to use EclipseLink MOXy to unmarshal an XML document, and marshal it to a JSON document, using JAXB-annotated classes.