package eclipselink.example.jpa.employee.model;

import java.util.Calendar;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-05-09T07:19:48.957-0400")
@StaticMetamodel(EmploymentPeriod.class)
public class EmploymentPeriod_ {
	public static volatile SingularAttribute<EmploymentPeriod, Calendar> startDate;
	public static volatile SingularAttribute<EmploymentPeriod, Calendar> endDate;
}
