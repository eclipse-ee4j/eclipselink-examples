EclipseLink Example
===================

Employee example model project illustrating an annotation mapped model. This project is leveraged by the employee.web and employee.web-js projects.

[EclipseLink Wiki: Employee JPA Example][1]
  
  
[1]: http://wiki.eclipse.org/EclipseLink/Examples/JPA/Employee