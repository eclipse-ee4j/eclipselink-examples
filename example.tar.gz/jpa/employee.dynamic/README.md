EclipseLink Dynamic Example
===========================

This example illustrates the use of EclipseLink's dynamic JPA support with the Employee example model. This approach uses 