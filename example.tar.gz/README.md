EclipseLink Example
===================

http://wiki.eclipse.org/EclipseLink/Examples