package test;

import org.junit.Test;

public class TestGeneration {

    @Test
    public void test() {
        
    }
}
