package eclipselink.example.mysports.persistence.test;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class ConfigTest {

	@Test
	public void verifyProviderServices() {

	}

	@Test
	public void verifyPremainInManifest() {

	}

}
