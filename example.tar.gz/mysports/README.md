EclipseLink MySports Example Application
========================================

This example application illustrates some of the latest features in EclipseLink 2.4 including extensible entities, tenant isolation, and externalized metadata storage. 

http://wiki.eclipse.org/EclipseLink/Examples/MySports
