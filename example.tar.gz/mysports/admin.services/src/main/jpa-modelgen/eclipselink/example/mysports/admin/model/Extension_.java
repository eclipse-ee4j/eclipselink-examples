package eclipselink.example.mysports.admin.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-02-22T10:11:27.052-0500")
@StaticMetamodel(Extension.class)
public class Extension_ {
	public static volatile SingularAttribute<Extension, HostedLeague> league;
	public static volatile SingularAttribute<Extension, String> type;
	public static volatile SingularAttribute<Extension, String> name;
	public static volatile SingularAttribute<Extension, String> javaType;
	public static volatile SingularAttribute<Extension, String> columnName;
}
