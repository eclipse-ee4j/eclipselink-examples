package eclipselink.example.mysports.admin.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-02-22T10:11:27.056-0500")
@StaticMetamodel(HostEnvironment.class)
public class HostEnvironment_ {
	public static volatile SingularAttribute<HostEnvironment, Integer> id;
	public static volatile SingularAttribute<HostEnvironment, String> name;
	public static volatile SingularAttribute<HostEnvironment, String> description;
}
