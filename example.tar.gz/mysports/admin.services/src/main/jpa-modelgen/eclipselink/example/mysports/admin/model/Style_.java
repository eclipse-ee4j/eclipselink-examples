package eclipselink.example.mysports.admin.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-02-22T10:11:27.057-0500")
@StaticMetamodel(Style.class)
public class Style_ {
	public static volatile SingularAttribute<Style, String> name;
	public static volatile SingularAttribute<Style, String> css;
}
