package eclipselink.example.mysports.admin.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2013-02-22T10:11:27.058-0500")
@StaticMetamodel(WebLogic.class)
public class WebLogic_ extends HostEnvironment_ {
}
