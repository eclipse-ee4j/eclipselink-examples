EclipseLink JPA-RS Student Example
==================================

http://wiki.eclipse.org/EclipseLink/Examples/JPARS/Simple

